// Board-impl.cc (implementation)
// Module: Board
// Description:
//   Initializes the 40 Square* instances that make up the Watopoly board.
//   Squares include ownable (AcademicBuilding, Residence, Gym) and
//   non-ownable (NEEDLESHALL, SLC, TUITION, DC Tims Line, etc.).
//
//   This class is purely structural — it owns the squares and exposes
//   access to them. Gameplay control is handled externally (e.g., by GameController).

module Board;

import <iostream>;
import <algorithm>;
import <memory>;
import AcademicBuilding;
import Residence;
import Gym;
import ActionSquares;

Board::Board() {
    // === Populate all 40 squares in order ===
    squares.emplace_back(std::make_unique<COLLECTOSAP>("COLLECT OSAP", 0));
    squares.emplace_back(std::make_unique<AcademicBuilding>("AL", 1, 40, "Arts1", 50));
    squares.emplace_back(std::make_unique<SLC>("SLC", 2));
    squares.emplace_back(std::make_unique<AcademicBuilding>("ML", 3, 60, "Arts1", 50));
    squares.emplace_back(std::make_unique<TUITION>("TUITION", 4));
    squares.emplace_back(std::make_unique<Residence>("MKV", 5, 200));
    squares.emplace_back(std::make_unique<AcademicBuilding>("ECH", 6, 100, "Arts2", 50));
    squares.emplace_back(std::make_unique<NEEDLESHALL>("NEEDLES HALL", 7));
    squares.emplace_back(std::make_unique<AcademicBuilding>("PAS", 8, 100, "Arts2", 50));
    squares.emplace_back(std::make_unique<AcademicBuilding>("HH", 9, 120, "Arts2", 50));
    squares.emplace_back(std::make_unique<DCTimsLine>("DC Tims Line", 10));
    squares.emplace_back(std::make_unique<AcademicBuilding>("RCH", 11, 140, "Eng", 100));
    squares.emplace_back(std::make_unique<Gym>("PAC", 12, 150));
    squares.emplace_back(std::make_unique<AcademicBuilding>("DWE", 13, 140, "Eng", 100));
    squares.emplace_back(std::make_unique<AcademicBuilding>("CPH", 14, 160, "Eng", 100));
    squares.emplace_back(std::make_unique<Residence>("UWP", 15, 200));
    squares.emplace_back(std::make_unique<AcademicBuilding>("LHI", 16, 180, "Health", 100));
    squares.emplace_back(std::make_unique<SLC>("SLC", 17));
    squares.emplace_back(std::make_unique<AcademicBuilding>("BMH", 18, 180, "Health", 100));
    squares.emplace_back(std::make_unique<AcademicBuilding>("OPT", 19, 200, "Health", 100));
    squares.emplace_back(std::make_unique<GooseNesting>("Goose Nesting", 20));
    squares.emplace_back(std::make_unique<AcademicBuilding>("EV1", 21, 220, "Env", 150));
    squares.emplace_back(std::make_unique<NEEDLESHALL>("NEEDLES HALL", 22));
    squares.emplace_back(std::make_unique<AcademicBuilding>("EV2", 23, 220, "Env", 150));
    squares.emplace_back(std::make_unique<AcademicBuilding>("EV3", 24, 240, "Env", 150));
    squares.emplace_back(std::make_unique<Residence>("V1", 25, 200));
    squares.emplace_back(std::make_unique<AcademicBuilding>("PHYS", 26, 260, "Sci1", 150));
    squares.emplace_back(std::make_unique<AcademicBuilding>("B1", 27, 260, "Sci1", 150));
    squares.emplace_back(std::make_unique<Gym>("CIF", 28, 150));
    squares.emplace_back(std::make_unique<AcademicBuilding>("B2", 29, 280, "Sci1", 150));
    squares.emplace_back(std::make_unique<GoToTims>("GO TO TIMS", 30));
    squares.emplace_back(std::make_unique<AcademicBuilding>("EIT", 31, 300, "Sci2", 200));
    squares.emplace_back(std::make_unique<AcademicBuilding>("ESC", 32, 300, "Sci2", 200));
    squares.emplace_back(std::make_unique<SLC>("SLC", 33));
    squares.emplace_back(std::make_unique<AcademicBuilding>("C2", 34, 320, "Sci2", 200));
    squares.emplace_back(std::make_unique<Residence>("REV", 35, 200));
    squares.emplace_back(std::make_unique<NEEDLESHALL>("NEEDLES HALL", 36));
    squares.emplace_back(std::make_unique<AcademicBuilding>("MC", 37, 350, "Math", 200));
    squares.emplace_back(std::make_unique<CoopFee>("COOP FEE", 38));
    squares.emplace_back(std::make_unique<AcademicBuilding>("DC", 39, 400, "Math", 200));
}


Square* Board::getSquare(int position) const {
    if (position < 0 || position >= static_cast<int>(squares.size())) return nullptr;
    return squares[position].get(); // access raw pointer
}

Square* Board::getSquareByName(const std::string& name) const {
    for (const auto& square : squares) {
        if (square->getName() == name) return square.get();
    }
    return nullptr;
}

void Board::display() const {
    std::cout << "=== WATOPOLY BOARD ===\n";
    for (const auto& square : squares) {
        std::cout << "[" << square->getPosition() << "] " << square->getName() << "\n";
    }
}
